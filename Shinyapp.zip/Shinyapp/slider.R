slider1limit <- 80
slider2limit <- 50
slider3limit <- 25
slider4limit <- 5

ui <-pageWithSidebar(
  
  # Application title
  headerPanel("Sliders should sum to 100!"),
  # Sidebar with sliders whos sum should be constrained to be 100
  sidebarPanel(
    sliderInput("slider1", "Slider 1: ", min = 0, max = 100, value = 0, step=1),
    uiOutput("slider2"),
    uiOutput("slider3"),
    uiOutput("slider4")),
  
  # Create table output
  mainPanel(tableOutput("restable"))
)

server <- function(input, output,session) {

# Slider 2
  output$slider2 <- renderUI({
    values <- min((100 - input$slider1),slider2limit)
    sliderInput("slider2", "Slider 2: ", min=0,max=100-input$slider1, value = values)
  })


# Slider 3
  output$slider3 <- renderUI({
    values <- min((100 - input$slider1 - input$slider2), slider3limit)
    sliderInput("slider3", "Slider 3: ", min=0,max=100-input$slider1-input$slider2, value = values)
  })
  
  output$restable <- renderTable({
    myvals<- c(input$slider1, input$slider2, input$slider3, 100-input$slider1-input$slider2-input$slider3)
    data.frame(Names=c("Slider 1", "Slider 2", "Slider 3", "Slider4"),
               Values=myvals)
  })
}

runApp(list(ui = ui, server = server))

